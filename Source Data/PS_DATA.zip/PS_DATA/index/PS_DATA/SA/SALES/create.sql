CREATE COLUMN TABLE "PS_DATA"."SALES" ("Customer_Name" NVARCHAR(40), "Customer_Segment" NVARCHAR(10), "Sector" NVARCHAR(16), "Country" NVARCHAR(13), "Customer_Status" NVARCHAR(16), "Annual_Speed" NVARCHAR(6), "Length_Of_Sales_Cycle" NVARCHAR(9), "Product_Name" NVARCHAR(18), "Highest_Contract_Level" NVARCHAR(28), "Compelling_Event" NVARCHAR(3), "RFP" NVARCHAR(3), "Sales_Engineer_Engaged" NVARCHAR(3), "Services_Included" NVARCHAR(3), "Customer_Meeting" TINYINT CS_INT, "License" SMALLINT CS_INT, "Contacts" TINYINT CS_INT, "Opportunity_Value" INTEGER CS_INT) UNLOAD PRIORITY 5  AUTO MERGE ;
COMMENT ON COLUMN "PS_DATA"."SALES"."Customer_Name" is ' ';
COMMENT ON COLUMN "PS_DATA"."SALES"."Customer_Segment" is ' ';
COMMENT ON COLUMN "PS_DATA"."SALES"."Sector" is ' ';
COMMENT ON COLUMN "PS_DATA"."SALES"."Country" is ' ';
COMMENT ON COLUMN "PS_DATA"."SALES"."Customer_Status" is ' ';
COMMENT ON COLUMN "PS_DATA"."SALES"."Annual_Speed" is ' ';
COMMENT ON COLUMN "PS_DATA"."SALES"."Length_Of_Sales_Cycle" is ' ';
COMMENT ON COLUMN "PS_DATA"."SALES"."Product_Name" is ' ';
COMMENT ON COLUMN "PS_DATA"."SALES"."Highest_Contract_Level" is ' ';
COMMENT ON COLUMN "PS_DATA"."SALES"."Compelling_Event" is ' ';
COMMENT ON COLUMN "PS_DATA"."SALES"."RFP" is ' ';
COMMENT ON COLUMN "PS_DATA"."SALES"."Sales_Engineer_Engaged" is ' ';
COMMENT ON COLUMN "PS_DATA"."SALES"."Services_Included" is ' ';
COMMENT ON COLUMN "PS_DATA"."SALES"."Customer_Meeting" is ' ';
COMMENT ON COLUMN "PS_DATA"."SALES"."License" is ' ';
COMMENT ON COLUMN "PS_DATA"."SALES"."Contacts" is ' ';
COMMENT ON COLUMN "PS_DATA"."SALES"."Opportunity_Value" is ' '