CREATE COLUMN TABLE "PS_DATA"."CENSUS" ("id" INTEGER CS_INT NOT NULL , "age" TINYINT CS_INT, "workclass" NVARCHAR(16), "fnlwgt" INTEGER CS_INT, "education" NVARCHAR(12), "education-num" TINYINT CS_INT, "marital-status" NVARCHAR(21), "occupation" NVARCHAR(17), "relationship" NVARCHAR(14), "race" NVARCHAR(18), "sex" NVARCHAR(6), "capital-gain" INTEGER CS_INT, "capital-loss" SMALLINT CS_INT, "hours-per-week" TINYINT CS_INT, "native-country" NVARCHAR(26), "class" SMALLINT CS_INT, PRIMARY KEY ("id")) UNLOAD PRIORITY 5  AUTO MERGE ;
COMMENT ON COLUMN "PS_DATA"."CENSUS"."id" is ' ';
COMMENT ON COLUMN "PS_DATA"."CENSUS"."age" is ' ';
COMMENT ON COLUMN "PS_DATA"."CENSUS"."workclass" is ' ';
COMMENT ON COLUMN "PS_DATA"."CENSUS"."fnlwgt" is ' ';
COMMENT ON COLUMN "PS_DATA"."CENSUS"."education" is ' ';
COMMENT ON COLUMN "PS_DATA"."CENSUS"."education-num" is ' ';
COMMENT ON COLUMN "PS_DATA"."CENSUS"."marital-status" is ' ';
COMMENT ON COLUMN "PS_DATA"."CENSUS"."occupation" is ' ';
COMMENT ON COLUMN "PS_DATA"."CENSUS"."relationship" is ' ';
COMMENT ON COLUMN "PS_DATA"."CENSUS"."race" is ' ';
COMMENT ON COLUMN "PS_DATA"."CENSUS"."sex" is ' ';
COMMENT ON COLUMN "PS_DATA"."CENSUS"."capital-gain" is ' ';
COMMENT ON COLUMN "PS_DATA"."CENSUS"."capital-loss" is ' ';
COMMENT ON COLUMN "PS_DATA"."CENSUS"."hours-per-week" is ' ';
COMMENT ON COLUMN "PS_DATA"."CENSUS"."native-country" is ' ';
COMMENT ON COLUMN "PS_DATA"."CENSUS"."class" is ' '